#include "menu.h"

menu::menu(QWidget *parent) : QMainWindow(parent)
{

}
