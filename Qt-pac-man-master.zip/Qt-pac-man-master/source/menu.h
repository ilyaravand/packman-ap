#ifndef MENU_H
#define MENU_H

#include <QMainWindow>

class menu : public QMainWindow
{
    Q_OBJECT
public:
    explicit menu(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // MENU_H